# Online hotel-reservation system 
**Online Hotel Reservation &amp; Management System**

How to run the Hotel Reservation Management System  Project
1. Download the  zip file
2. Extract the file and copy hotelreservation folder
3. Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)
4. Open PHPMyAdmin (http://localhost/phpmyadmin)
5. Create a database with name hotel
6. Import hotel.sql file(given inside the zip package in sql file )
7. Run the script http://localhost/hotelreservation (frontend)
8. For admin panel http://localhost/hotelreservation/admin/login.php  (admin panel)

Credential for admin panel :
Admin Credentials:

username: admin
password: 1234 

**User Role**

- User can view Room facilities, price and availability of the room
- They can book their desire room from online.

**Admin Role**

- Secure Login System for Admin Panel
- Add, Delete, Edit Room Facilities
- Add, Delete, Edit Room Category
- ADD, Remove, Edit Number of Rooms
- View Booked Room
- Add new Admin / User
- View all information

