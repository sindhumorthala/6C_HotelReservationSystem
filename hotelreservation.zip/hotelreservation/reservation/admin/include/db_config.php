<?php
    define('DB_SERVER','localhost');
    define('DB_USERNAME','root');
    define('DB_PASSWORD','root');
    define('DB_DATABASE','hotel');

?>